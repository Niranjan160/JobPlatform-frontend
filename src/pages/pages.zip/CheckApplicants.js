// src/pages/CheckApplicants.js
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import "./CheckApplicants.css";

const CheckApplicants = () => {
  const { jobId } = useParams();
  const [job, setJob] = useState(null);
  const [applicants, setApplicants] = useState([]);
  const [expandedApplicantId, setExpandedApplicantId] = useState(null);

  useEffect(() => {
    const fetchJobAndApplicants = async () => {
      try {
        const jobRes = await axios.get(`http://localhost:8080/api/jobs/${jobId}`);
        setJob(jobRes.data);

        const applicantRes = await axios.get(`http://localhost:8080/api/jobs/${jobId}/applicants`);
        setApplicants(applicantRes.data);
      } catch (err) {
        console.error("Error fetching job or applicants:", err);
      }
    };

    fetchJobAndApplicants();
  }, [jobId]);

  const toggleDetails = (userId) => {
    setExpandedApplicantId(prev => (prev === userId ? null : userId));
  };

  const handleAccept = (applicantId) => {
    alert(`Accepted applicant ID: ${applicantId}`);
  };

  const handleReject = (applicantId) => {
    alert(`Rejected applicant ID: ${applicantId}`);
  };

  if (!job) return <div className="jobdetails-container">Loading job details...</div>;

  return (
    <div className="jobdetails-container">
      <h2>{job.title}</h2>
      <p><strong>Description:</strong> {job.description}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p><strong>Salary:</strong> ₹{job.salary}</p>
      <p><strong>Type:</strong> {job.jobType}</p>
      <p><strong>Category:</strong> {job.jobCategories}</p>
      <hr />
      <h3>Applicants</h3>
      {applicants.length === 0 ? (
        <p>No applicants yet.</p>
      ) : (
        <div className="applicant-list">
          {applicants.map((applicant) => (
            <div key={applicant.userId} className="applicant-card">
              <div className="applicant-header">
                <div>
                  <strong>{applicant.name}</strong> – {applicant.email} – {applicant.mobileNo}
                </div>
                <button onClick={() => toggleDetails(applicant.userId)}>
                  {expandedApplicantId === applicant.userId ? "Hide Details" : "Details"}
                </button>
              </div>

              {expandedApplicantId === applicant.userId && (
                <div className="applicant-details">
                  <p><strong>Experience:</strong> {applicant.experience} yrs</p>
                  <p><strong>Address:</strong> {applicant.address}</p>
                  <p><strong>DOB:</strong> {applicant.dob}</p>
                  {/* <p>
                    <strong>Resume:</strong>{" "}
                    {applicant.resumeUrl ? (
                      <a href={`http://localhost:8080${applicant.resumeUrl}`} target="_blank" rel="noreferrer">
                        View
                      </a>
                    ) : (
                      "N/A"
                    )}
                  </p> */}
                  <div className="applicant-actions">
                    <button className="accept-btn" onClick={() => handleAccept(applicant.userId)}>Accept</button>
                    <button className="reject-btn" onClick={() => handleReject(applicant.userId)}>Reject</button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CheckApplicants;
